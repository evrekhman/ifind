<?php

class ProductController
{


		public function actionList()
		{
			return true;
		}


}