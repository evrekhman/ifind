<?php

//отдельная страничка для счетчиков
class XxxController {

	public function actionIndex()
	{
		
		
		
		require_once(ROOT . '/views/xxx/index.php');

		return true;
	}

	

}

