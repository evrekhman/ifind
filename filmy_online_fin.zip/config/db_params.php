<?php

return array(
			'host' => 'localhost',
			'dbname' => 'films',
			'user' => 'films',
			'password' => 'visacard2',
);