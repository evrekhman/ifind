


   



    <script src="https://code.jquery.com/ui/1.11.4/jquery-ui.min.js"></script>
     <script src="/template/js/parser.js<? echo "?".rand(2000,9999)?>"></script>
    <script>
       
        parserKino();
    </script>
    <!-- Yandex.Metrika counter -->


</body>

</html>
