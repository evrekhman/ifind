<?php include ROOT.'/views/layouts/header.php';?>

  <div>
    
   
  <div class="panal">
     <div class="parsTable">
       <div class="parsCollum"> 
         <div class="parsJson">парсинг json</div>
         <div class="addInfo"></div>
       </div>
       <div class="parsCollum2">
         <div class="creatJson">создание уникальных фильмов</div>
         <div class="addInfo2"></div>
       </div>
       <div class="parsCollum4">
         <input type="text" class="vv" placeholder="id скакого начинать цикл" />
         <div class="insertJson4">уникальные Фильмы</div>
         <div class="addInfo4"></div>
       </div>
       <div class="parsCollum3">
         
         <input type="text" class="vl"/>
         <div class="insertJson">пополнение остальной информацией</div>
         
         <div class="addInfo3"></div>
         
       </div>
       
     </div>
  </div>
   </div>

    
<?php include ROOT.'/views/layouts/footer.php';?>