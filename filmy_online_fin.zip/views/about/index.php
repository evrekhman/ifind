
<?php include ROOT.'/views/layouts/header.php';?>
<div class="container" style="height:100px ;">
  <div class="row">
    <div class="col-md-4"></div>
    <div class="col-md-4"><h1>Обратная связь</h1>
    </div>
    <div class="col-md-4"></div>
  </div>
</div>
<div class="container" id="hei">
  <div class="row">
    <div class="col-md-4"></div>
    <div class="col-md-4"><p>Поддержка пользователей и Правообладателей</p> <p>пишите по email:</p>
                          <p>filmy-online@protonmail.com</p>
    </div>
    <div class="col-md-4"></div>
  </div>
</div>

<?php include ROOT.'/views/layouts/footer.php';?>
